package com.barclay.tests.exceptions;

/**
 * Created by robinwang on 9/18/16.
 */
public class NoMatchMarketRuleExeption extends Exception{
    public NoMatchMarketRuleExeption(String message) {
        super(message);
    }
}
