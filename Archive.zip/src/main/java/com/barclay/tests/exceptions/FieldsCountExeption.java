package com.barclay.tests.exceptions;

/**
 * Created by robinwang on 9/18/16.
 */
public class FieldsCountExeption extends Exception{
    public FieldsCountExeption(String message) {
        super(message);
    }
}
